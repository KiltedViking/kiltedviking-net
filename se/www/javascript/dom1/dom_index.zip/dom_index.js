
//Koppla funktionen minFunktion() till laddning av sida (h�ndelsen load)
addLoadEvent(minFunktion); //Koppla funktion till sidladdning

function minFunktion()
{
  alert('Sida laddats'); //Ta bort n�r koppling fungerar...
  //Placera kod h�r som ska exekveras n�r sida laddas
}

//�vriga av dina funktioner h�r...
